import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Route } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { TasksComponent } from './tasks/tasks.component';
import { CompletedComponent } from './completed/completed.component';
import { CommonModule } from '@angular/common';


const routes : Route[] = [
  {
    path: 'tasks',
    component: TasksComponent
  },
  {
    path:'completed',
    component: CompletedComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    TasksComponent,
    CompletedComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
