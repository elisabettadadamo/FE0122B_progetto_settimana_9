import { Todo} from "./models/todo";
let todos: Todo[] = [];

//lettura array
export function get(): Promise<Todo[]> {
  return new Promise((res, rej) => {
    setTimeout(() => {
      res(todos);
    },2000);
  });
}

//aggiungi
export function addTask(todo: Omit<Todo, 'id'>): Promise<Todo>{
  return new Promise((res, rej) =>{
    setTimeout(() =>{
      const newTodo: Todo = {...todo,id:todos.length +1};
      todos.push(newTodo)
      res(newTodo);
    },2000);
  });
}

//rimuovi
export function rimuovi(todo: Todo): Promise<number> {
  return new Promise((res,rej) =>{
    setTimeout(() =>{
      todos= todos.filter((todo)=> todo.id !==todo.id);
      res(todo.id);
    },2000);
  });
}


//modifica
export function modifica(newTodo: Partial<Todo>, id: number): Promise<Todo> {
  return new Promise((res, rej) => {
    setTimeout(() => {
      todos = todos.map((todo) =>
        todo.id == id ? { ...todo, ...newTodo } : todo
      );
      const modTodo = todos.find((todo) => todo.id == id);
      if (modTodo) {
        res(modTodo);
      } else {
        rej('todo non trovato');
      }
    }, 2000);
  });
}
